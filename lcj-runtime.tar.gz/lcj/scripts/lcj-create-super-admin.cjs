#!/usr/bin/env node
/**
 * Create an LCJ SUPER_ADMIN account from a trusted server TTY.
 *
 * Password input is hidden and is never accepted through argv or environment variables.
 */
'use strict';

require('reflect-metadata');

const { createInterface } = require('node:readline');
const { Writable } = require('node:stream');
const argon2 = require('argon2');
const mainDataSource = require('../dist/database/data-source-main').default;
const { User, UserRole } = require('../dist/modules/users/entities/user.entity');
const { validateNewPassword } = require('../dist/modules/users/password-policy');

function prompt(query) {
  return new Promise(resolve => {
    const rl = createInterface({ input: process.stdin, output: process.stdout, terminal: true });
    rl.question(query, answer => {
      rl.close();
      resolve(answer.trim());
    });
  });
}

function promptHidden(query) {
  return new Promise(resolve => {
    const output = new Writable({
      write(chunk, _encoding, callback) {
        if (!output.muted) process.stdout.write(chunk);
        callback();
      },
    });
    output.muted = false;

    const rl = createInterface({ input: process.stdin, output, terminal: true });
    process.stdout.write(query);
    output.muted = true;
    rl.question('', answer => {
      output.muted = false;
      rl.close();
      process.stdout.write('\n');
      resolve(answer);
    });
  });
}

async function main() {
  if (!process.stdin.isTTY || !process.stdout.isTTY) {
    throw new Error('Perintah ini wajib dijalankan dari terminal interaktif.');
  }

  console.log('=== LCJ Admin System — Buat Super Admin ===\n');
  await mainDataSource.initialize();

  try {
    const users = mainDataSource.getRepository(User);
    const username = (await prompt('Username: ')).toLowerCase();

    if (!username) throw new Error('Username tidak boleh kosong.');
    if (await users.findOne({ where: { username } })) {
      throw new Error(`Username "${username}" sudah dipakai.`);
    }

    const displayName = await prompt('Nama tampilan (Enter untuk pakai username): ') || username;
    const password = await promptHidden('Password (min. 12 karakter): ');
    const confirmation = await promptHidden('Konfirmasi password: ');
    const passwordError = validateNewPassword(password, confirmation);
    if (passwordError) throw new Error(passwordError);

    const passwordHash = await argon2.hash(password, { type: argon2.argon2id });
    await users.save(users.create({
      username,
      displayName,
      passwordHash,
      role: UserRole.SUPER_ADMIN,
      isActive: true,
    }));

    console.log(`\nSuper admin "${username}" berhasil dibuat.`);
  } finally {
    await mainDataSource.destroy();
  }
}

main().catch(error => {
  console.error(`\nGagal membuat super admin: ${error instanceof Error ? error.message : String(error)}`);
  process.exitCode = 1;
});
