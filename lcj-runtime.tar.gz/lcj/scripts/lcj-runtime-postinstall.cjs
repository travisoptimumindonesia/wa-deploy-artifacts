'use strict';

const { spawnSync } = require('node:child_process');
const path = require('node:path');

const patchers = [
  'patch-wwebjs-201832.js',
  'patch-wwebjs-newsletter-preview.js',
  'patch-wwebjs-status.js',
  'patch-wwebjs-ready-sync.js',
];

for (const patcher of patchers) {
  const result = spawnSync(process.execPath, [path.join(__dirname, patcher), '--best-effort'], {
    stdio: 'inherit',
  });
  if (result.error || result.status !== 0) {
    console.error(`LCJ runtime postinstall failed at ${patcher}`);
    process.exit(result.status || 1);
  }
}
