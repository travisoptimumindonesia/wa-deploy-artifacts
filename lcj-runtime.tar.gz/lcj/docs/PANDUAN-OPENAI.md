# BIP ADMIN SYSTEM — Panduan Setup OpenAI (opsional)

Dokumen ini menjelaskan cara memakai OpenAI sebagai penyedia "otak" AI untuk agen
WhatsApp kamu, sebagai alternatif dari APImart/OpenRouter yang sudah ada.
OpenAI adalah salah satu pilihan penyedia LLM — bukan satu-satunya, dan bukan yang
diwajibkan.

**Penting:** BIP ADMIN SYSTEM bukan produk resmi OpenAI, dan tidak berafiliasi,
disponsori, atau didukung oleh OpenAI. Integrasi ini hanya memanggil API publik
OpenAI menggunakan API key milik kamu sendiri.

## 1. Membuat API key OpenAI khusus untuk instalasi ini

1. Buat/masuk ke akun di https://platform.openai.com.
2. Buka **Settings → API keys** (atau `platform.openai.com/api-keys`).
3. Klik **Create new secret key**. Beri nama yang jelas, misalnya
   `bip-admin-<nama-toko>`, supaya gampang dikenali dan dicabut nanti kalau perlu
   tanpa mengganggu key lain.
4. Salin key tersebut (formatnya diawali `sk-...`). OpenAI **hanya menampilkannya
   sekali** — kalau lupa disalin, kamu harus membuat key baru.
5. Tempel key itu di dashboard BIP ADMIN SYSTEM, menu **AI Agent**, pada kolom
   **API Key**, lalu klik **Simpan Konfigurasi LLM**.

## 2. Jangan pernah menaruh key di tempat yang salah

- **Jangan** commit API key ke kode sumber atau ke repository Git (termasuk
  fork/branch pribadi) — sekali sebuah key pernah ter-push ke GitHub, anggap key
  itu bocor permanen (riwayat commit tetap bisa dilihat), cabut dan buat yang baru.
- **Jangan** isi API key sungguhan ke dalam `.env.example` — file itu adalah
  template kosong yang ikut terunggah ke repository; isi API key asli hanya di
  file `.env` lokal instalasi kamu, yang tidak pernah ikut ter-commit.
- **Jangan** kirim API key lewat chat/screenshot yang bisa terekam permanen
  (grup WhatsApp publik, tiket support yang tidak terenkripsi, dsb).
- Kalau curiga sebuah key sudah bocor, langsung **Revoke** key itu di
  platform.openai.com dan buat key baru — jauh lebih cepat daripada berusaha
  "menariknya kembali".

Dashboard BIP ADMIN SYSTEM sendiri tidak pernah menampilkan API key yang sudah
tersimpan secara utuh (lihat bagian 4) — permukaan risiko terbesar untuk
kebocoran key ada di luar dashboard, di tempat-tempat di atas.

## 3. Memilih model

Kolom **Model** di menu AI Agent menerima nama model apa pun (bebas diketik
manual, misalnya kalau OpenAI merilis model baru), dan juga menawarkan beberapa
pilihan hemat lewat autocomplete:

| Model | Cocok untuk |
|---|---|
| `gpt-4o-mini` (disarankan, default) | Balasan chat CS sehari-hari, paling hemat |
| `gpt-4o` | Kualitas lebih tinggi, biaya lebih mahal per balasan |
| `gpt-4.1-mini` | Alternatif hemat lainnya |
| `gpt-3.5-turbo` | Paling murah, kualitas lebih sederhana |

Untuk kebanyakan toko, `gpt-4o-mini` sudah cukup dan paling ekonomis. Ganti model
kapan saja dari menu yang sama tanpa perlu mengganti API key.

## 4. Melihat status konfigurasi tanpa membuka key

Di menu **AI Agent**, kolom API key yang sudah tersimpan selalu ditampilkan dalam
bentuk tersamar (contoh: `sk-•••••••1234`) — dashboard tidak pernah menampilkan
key asli secara utuh setelah disimpan, baik di layar maupun lewat API. Untuk
mengetahui apakah integrasi berjalan normal, lihat label **status** di sebelah
key:

| Status | Artinya |
|---|---|
| Belum dikonfigurasi | Belum ada API key tersimpan untuk sesi ini |
| Terkonfigurasi | Key tersimpan, belum ada masalah yang tercatat |
| Key ditolak | OpenAI menolak key ini (salah/kadaluarsa/dicabut) — buat key baru |
| Saldo/kuota habis | Saldo OpenAI habis atau kuota tagihan tercapai — isi saldo/limit |
| Rate limit | Terlalu banyak permintaan dalam waktu singkat — biasanya reda sendiri |
| Provider bermasalah | Gangguan sementara di sisi OpenAI atau jaringan |

Status ini terisi otomatis dari hasil percakapan nyata terakhir dengan OpenAI —
bukan tombol "tes koneksi" terpisah, jadi status baru muncul setelah agen benar-
benar mencoba membalas sekali.

## 5. Mengganti atau menghapus key

- **Ganti key**: klik **Ganti Key** di sebelah key tersamar, ketik key baru, lalu
  **Simpan Konfigurasi LLM**.
- **Hapus key**: klik **Hapus Key**, lalu konfirmasi. Ini satu-satunya cara key
  terhapus — menyimpan form kosong **tidak pernah** menghapus key yang sudah
  tersimpan, supaya kamu tidak tidak sengaja mematikan agen saat sedang
  mengedit pengaturan lain.

## 6. Biaya OpenAI terpisah dari BIP ADMIN SYSTEM

- Biaya pemakaian OpenAI ditagih **langsung oleh OpenAI ke akun OpenAI kamu**,
  terpisah sepenuhnya dari biaya BIP ADMIN SYSTEM. Kami tidak menerima,
  meneruskan, atau menandai naik biaya OpenAI dengan cara apa pun.
- Cek pemakaian real-time di https://platform.openai.com/usage.

### Menetapkan batas pengeluaran (sangat disarankan)

Supaya biaya tidak membengkak tak terduga (misalnya karena lonjakan chat atau
kesalahan konfigurasi):

1. Buka https://platform.openai.com/settings/organization/limits (atau
   **Settings → Billing → Limits**).
2. Atur **usage limit** bulanan sesuai anggaran toko kamu.
3. Aktifkan notifikasi email saat mendekati batas, kalau tersedia.

Batas ini murni fitur akun OpenAI kamu — BIP ADMIN SYSTEM tidak bisa
mengatur atau melihat limit ini dari dashboard.
