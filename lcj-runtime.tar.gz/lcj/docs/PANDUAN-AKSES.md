# LCJ - Panduan Akses

Dokumen ini menjelaskan cara menyiapkan LCJ sampai bot dapat membantu membalas chat pertama.

## Yang perlu disiapkan

- Laptop atau PC yang menyala saat bot bekerja (macOS, Windows, atau Linux).
- Nomor WhatsApp khusus untuk CS toko kamu (sangat disarankan bukan nomor pribadi utama).
- **API key AI (bayar sendiri, murah)**: LCJ memakai "otak" AI dari penyedia pihak ketiga. Daftar di https://apimart.ai (atau openrouter.ai), beli kredit secukupnya. Dengan model hemat (gpt-4o-mini), biaya kira-kira Rp15-40 per balasan chat.

Tidak perlu Docker. Pemasangnya menyiapkan sendiri semua kebutuhannya.

## Cara install (satu perintah, sekali saja)

Buka **Terminal** (macOS: tekan Cmd+Spasi, ketik Terminal, Enter), lalu tempel perintah ini dan tekan Enter:

```
bash install.sh
```

Itu saja. Pemasangnya akan:
- memasang Node.js kalau belum ada (ke folder kamu sendiri, tanpa password),
- menyiapkan browser yang dipakai untuk menyambung WhatsApp,
- menjalankan LCJ dari release yang sudah diterima,
- membuka dashboard di browser,
- lalu **menampilkan API key login kamu di layar. Simpan key itu.**

Tunggu sampai selesai (sekitar 3-6 menit pada pemasangan pertama, tergantung internet).

**Khusus Windows:** jalankan perintah di atas lewat **Git Bash** atau terminal **Ubuntu (WSL)**.

## Pengaturan awal

1. Buka dashboard di browser: `http://localhost:2785`
2. Login pakai API key yang muncul di akhir install.
3. Menu **Sessions**: buat sesi baru, **scan QR** pakai WhatsApp nomor CS kamu (seperti WhatsApp Web).
4. Menu **AI Agent**: konfigurasi penyedia AI yang didukung dan mulai dari mode supervised.

## Penting untuk diketahui (jujur dari kami)

- LCJ memakai jalur WhatsApp tidak resmi (seperti semua tool sejenis). Ada risiko nomor dibatasi oleh WhatsApp. Pakai nomor khusus CS, aktifkan jeda balas di pengaturan, dan hindari spam. Risiko ini di luar kendali kami.
- Balasan AI dihasilkan lewat penyedia AI pihak ketiga pilihanmu; isi chat pelanggan dikirim ke penyedia itu untuk dibalas. Data lain tersimpan di komputermu sendiri.
- Kendala teknis? Support via WhatsApp 0831-8392-9631 sampai jalan.
