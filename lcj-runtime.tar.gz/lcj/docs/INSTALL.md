# LCJ: Installation Guide

LCJ is a self-hosted AI WhatsApp customer-service agent.

---

## Prerequisites

- **macOS / Linux / VPS:** nothing to prepare. The installer installs Node.js into your home directory when it is missing (no password needed) and downloads a browser for WhatsApp. Git is optional: without it the installer downloads a release tarball instead — which is the default flow.
- **Windows:** run the command below from **Git Bash** or an **Ubuntu (WSL)** terminal.
- Internet access on first run (dependencies plus a ~150 MB browser download, one time only).
- Prefer Docker? `LCJ_MODE=docker bash install.sh` still works.

No Node.js, Python, or other runtimes needed on the host.

---

## Install (one command)

From an authorized LCJ release directory, run:

```bash
bash install.sh
```

That's it. The script will:

1. Install Node.js 22 if missing (into your home directory, no sudo).
2. Install the LCJ runtime from the authorized release directory.
3. Create a `.env` file and generate a secure random secret unique to this install.
4. Pick a free port (2785 by default, the next free one if it is taken).
5. Install dependencies and a managed Chromium, then start LCJ.
6. Open the dashboard and print the API key you log in with.

First build takes 3-10 minutes depending on your internet connection. Subsequent runs are fast (image is cached).

---

## What to expect

```
[info]  === Pemasangan LCJ ===
[ok]    Node.js v22.x siap
[info]  Mengunduh LCJ...
[info]  Membuat .env
[ok]    Kunci enkripsi unik dibuat
[info]  Menjalankan LCJ (pertama kali agak lama karena membangun image)...
[ok]    LCJ siap dipakai
[ok]    ============================================================
[ok]      LCJ jalan di http://localhost:2785
[ok]    ============================================================

  API KEY LOGIN DASHBOARD (SIMPAN INI):
  <YOUR_LCJ_API_KEY>
```

---

## Open the dashboard

Navigate to: **http://localhost:2785**

**Login:** the installer prints your dashboard API key (starts with `wtm_k1_`) at the end of the install. It is also saved to `data/.api-key` inside the repo folder. Paste it on the login screen.

First-time setup steps in the dashboard:

1. **Sessions** - click "New Session", then scan the QR code with your WhatsApp mobile app.
2. **AI Agent** - configure the supported AI provider, then enable supervised mode first.

---

## Update

To pull the latest version, re-run the installer in update mode. It re-downloads the latest release and preserves your `.env` and `data/`:

```bash
cd ~/lcj
LCJ_UPDATE=1 bash install.sh
```

No vendor activation step is required by the LCJ edition.

## Stop &amp; Start

- **Stop:** `bash ~/lcj/stop.sh`
- **Start:** `bash ~/lcj/start.sh`

Your data (sessions, database, media) lives in `./data/` and is preserved across stop/start cycles.

---

## Troubleshooting

**"Dashboard tampil blank / putih"**
: Ini biasanya karena browser meng-upgrade HTTP ke HTTPS untuk aset dashboard. Muat ulang (F5). Kalau masih blank, pastikan kamu membuka `http://` (bukan https) dan IP/domain yang benar (untuk VPS: `http://IP_VPS:2785`, bukan localhost).

**QR sesi tidak muncul / lambat**
: Setelah restart, tunggu 20–40 detik — browser WhatsApp butuh waktu start. QR biasanya muncul setelah itu.

**QR gagal / "Target closed" / barcode tidak bisa generate**
: Dipastikan cuma ada SATU proses LCJ yang jalan (RAM kecil + 2 proses = browser kehabisan memori). Matikan manual: `bash ~/lcj/stop.sh`, lalu `bash ~/lcj/start.sh`. Cukup satu proses yang pegang port 2785.

**Port 2785 already in use**
: The installer detects this and moves to the next free port (2786, 2787, ...), printing the one it chose. To force a specific port: `APP_PORT=3000 bash install.sh`.

**WhatsApp session drops after a restart**
: This is normal. Go to Sessions and scan the QR again.

---

## Install via AI agent

If you prefer to let an AI coding agent (Claude Code, Cursor, Windsurf, etc.) handle the installation, paste the following prompt into it:

```
I need to install and run LCJ (a self-hosted AI WhatsApp customer-service agent).

Steps:
1. Run the installer (it installs Node.js if needed, downloads the app, builds the dashboard, and starts it):
   curl -fsSL https://lcj.com/install.sh | bash

2. Verify the app is healthy:
   curl http://localhost:2785/api/health/ready

3. Open http://localhost:2785 in the browser and confirm the dashboard loads.

If the health check fails, check the process and logs under ~/lcj and report what you find.

Report back: whether the app is up, what the health endpoint returned, and
the URL to open the dashboard.
```

---

## File locations

| Path | Purpose |
|---|---|
| `.env` | Your configuration (auto-created by installer, never committed) |
| `.env.example` | Template showing all available options |
| `data/` | Persistent data: sessions, SQLite DB, media, `.api-key` |
| `start.sh` / `stop.sh` | Generated launcher scripts (auto-delegate to systemd on Linux/WSL) |

---

## Windows (WSL2 / Git Bash)

1. **Git Bash:** install [Git for Windows](https://git-scm.com/downloads), right-click in any folder → "Git Bash Here", then run the install command.
2. **WSL2:** install [Windows Subsystem for Linux](https://learn.microsoft.com/windows/wsl/install) (Ubuntu recommended), open the Ubuntu terminal, then run the install command.
3. Access the dashboard from Windows at **http://localhost:2785**.
